import React from "react";
import ReactDOM from "react-dom/client";
import "wanted-sans/fonts/webfonts/variable/complete/WantedSansVariable.css";
import "@fontsource/ibm-plex-mono/400.css";
import "@fontsource/ibm-plex-mono/500.css";
import App from "./App";
import "./styles.css";

ReactDOM.createRoot(document.getElementById("root")!).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>,
);
